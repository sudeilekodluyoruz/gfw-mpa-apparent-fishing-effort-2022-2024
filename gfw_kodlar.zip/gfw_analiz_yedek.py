
from __future__ import annotations

import re
from pathlib import Path

import matplotlib
matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

PROJECT_DIR = Path(__file__).resolve().parent
DATA_DIR = PROJECT_DIR
OUTPUT_DIR = PROJECT_DIR / "outputs"
CHUNK_SIZE = 1_000_000

COLUMNS = [
    "year", "month", "cell_ll_lat", "cell_ll_lon",
    "flag", "geartype", "hours", "fishing_hours"
]

SUM_COLUMNS = ["hours", "fishing_hours"]
KEYS = ["year", "month", "flag", "geartype"]

FILE_RE = re.compile(
    r"fleet-monthly-csvs-10-v3-(\d{4})-(\d{2})-(\d{2})\.csv$"
)


def find_monthly_files():

    files = sorted(
        DATA_DIR.rglob("fleet-monthly-csvs-10-v3-20??-??-??.csv")
    )

    if not files:
        raise FileNotFoundError("Aylik GFW CSV dosyasi bulunamadi.")

    seen = {}

    for path in files:
        match = FILE_RE.search(path.name)

        if not match:
            continue

        year, month, day = map(int, match.groups())

        if not 1 <= month <= 12 or not 1 <= day <= 31:
            raise ValueError(f"Gecersiz dosya tarihi: {path.name}")

        key = (year, month)

        if key in seen:
            raise ValueError(
                f"Ayni ay icin birden fazla dosya var:\n"
                f"{seen[key]}\n{path}"
            )

        seen[key] = path

    years = sorted({year for year, month in seen})

    missing = [
        f"{year}-{month:02d}"
        for year in years
        for month in range(1, 13)
        if (year, month) not in seen
    ]

    if missing:
        print("UYARI - Eksik aylar:", ", ".join(missing))
    else:
        print(f"Dosya kontrolu basarili: {len(seen)} aylik dosya.")

    return files


def aggregate_data(files):

    main_parts = []
    grid_parts = []
    quality_rows = []

    for n, path in enumerate(files, start=1):

        print(f"[{n}/{len(files)}] Okunuyor: {path.name}")

        match = FILE_RE.search(path.name)
        file_year = int(match.group(1))
        file_month = int(match.group(2))

        stats = {
            "file": path.name,
            "rows_read": 0,
            "rows_used": 0,
            "invalid_numeric_rows": 0,
            "invalid_date_rows": 0,
            "filename_date_mismatch_rows": 0,
            "invalid_coordinate_rows": 0,
            "negative_hour_rows": 0,
            "fishing_gt_ais_rows": 0,
            "missing_flag_rows": 0,
            "missing_geartype_rows": 0
        }

        for chunk in pd.read_csv(
            path,
            usecols=COLUMNS,
            chunksize=CHUNK_SIZE
        ):

            stats["rows_read"] += len(chunk)

            numeric_cols = [
                "year", "month",
                "cell_ll_lat", "cell_ll_lon",
                "hours", "fishing_hours"
            ]

            for col in numeric_cols:
                chunk[col] = pd.to_numeric(
                    chunk[col], errors="coerce"
                )

            valid = chunk[numeric_cols].notna().all(axis=1)

            stats["invalid_numeric_rows"] += int((~valid).sum())
            chunk = chunk.loc[valid].copy()

            if chunk.empty:
                continue

            valid_date = (
                chunk["year"].between(1900, 2100)
                & chunk["month"].between(1, 12)
                & chunk["year"].mod(1).eq(0)
                & chunk["month"].mod(1).eq(0)
            )

            stats["invalid_date_rows"] += int((~valid_date).sum())
            chunk = chunk.loc[valid_date].copy()

            if chunk.empty:
                continue

            mismatch = (
                chunk["year"].ne(file_year)
                | chunk["month"].ne(file_month)
            )

            stats["filename_date_mismatch_rows"] += int(
                mismatch.sum()
            )

            chunk = chunk.loc[~mismatch].copy()

            if chunk.empty:
                continue

            valid_coords = (
                chunk["cell_ll_lat"].between(-90, 90)
                & chunk["cell_ll_lon"].between(-180, 180)
            )

            stats["invalid_coordinate_rows"] += int(
                (~valid_coords).sum()
            )

            chunk = chunk.loc[valid_coords].copy()

            if chunk.empty:
                continue

            valid_hours = (
                chunk["hours"].ge(0)
                & chunk["fishing_hours"].ge(0)
            )

            stats["negative_hour_rows"] += int(
                (~valid_hours).sum()
            )

            chunk = chunk.loc[valid_hours].copy()

            if chunk.empty:
                continue

            # fishing_hours > hours olan satirlari raporla,
            # ancak otomatik olarak silme.
            stats["fishing_gt_ais_rows"] += int(
                chunk["fishing_hours"].gt(chunk["hours"]).sum()
            )

            stats["missing_flag_rows"] += int(
                chunk["flag"].isna().sum()
            )

            stats["missing_geartype_rows"] += int(
                chunk["geartype"].isna().sum()
            )

            chunk["flag"] = chunk["flag"].fillna("Unknown")
            chunk["geartype"] = chunk["geartype"].fillna("Unknown")

            chunk["flag"] = chunk["flag"].astype(str)
            chunk["geartype"] = chunk["geartype"].astype(str)

            chunk["lat"] = np.floor(
                chunk["cell_ll_lat"]
            ).astype("int16")

            chunk["lon"] = np.floor(
                chunk["cell_ll_lon"]
            ).astype("int16")

            main_parts.append(
                chunk.groupby(
                    KEYS, as_index=False
                )[SUM_COLUMNS].sum()
            )

            grid_parts.append(
                chunk.groupby(
                    ["year", "lat", "lon"],
                    as_index=False
                )["fishing_hours"].sum()
            )

            stats["rows_used"] += len(chunk)

        quality_rows.append(stats)

    if not main_parts:
        raise RuntimeError("Analiz icin gecerli veri bulunamadi.")

    main = (
        pd.concat(main_parts, ignore_index=True)
        .groupby(KEYS, as_index=False)[SUM_COLUMNS]
        .sum()
    )

    grid = (
        pd.concat(grid_parts, ignore_index=True)
        .groupby(
            ["year", "lat", "lon"],
            as_index=False
        )["fishing_hours"]
        .sum()
    )

    quality = pd.DataFrame(quality_rows)

    return main, grid, quality


def save_outputs(main, grid, quality):

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    # Mevcut dosya isimlerini koruyoruz.
    main.to_csv(
        OUTPUT_DIR / "year_month_flag_gear.csv",
        index=False
    )

    grid.to_csv(
        OUTPUT_DIR / "grid_1deg_by_year.csv",
        index=False
    )

    quality.to_csv(
        OUTPUT_DIR / "data_quality_report.csv",
        index=False
    )

    # Yillik toplamlar
    yearly = main.groupby("year")[SUM_COLUMNS].sum()

    yearly["fishing_ratio_pct"] = (
        yearly["fishing_hours"]
        / yearly["hours"].replace(0, np.nan)
        * 100
    )

    print("\nYILLIK TOPLAMLAR")
    print(yearly.round(2).to_string())

    # Mevsimsellik
    seasonal = (
        main.groupby(["year", "month"])["fishing_hours"]
        .sum()
        .unstack("year")
        .reindex(range(1, 13))
    )

    fig, ax = plt.subplots(figsize=(11, 6))

    seasonal.plot(ax=ax, marker="o", linewidth=2)

    ax.set(
        title="Aylik gorunur av saati (yillara gore)",
        xlabel="Ay",
        ylabel="Av saati"
    )

    ax.set_xticks(range(1, 13))
    ax.grid(True, alpha=0.25)

    fig.tight_layout()
    fig.savefig(
        OUTPUT_DIR / "seasonality_by_year.png",
        dpi=160
    )
    plt.close(fig)

    # Ilk 10 bayrak
    flag_year = (
        main.groupby(["flag", "year"])["fishing_hours"]
        .sum()
        .unstack("year", fill_value=0)
    )

    top_flags = flag_year.sum(axis=1).nlargest(10).index

    fig, ax = plt.subplots(figsize=(11, 6))

    flag_year.loc[top_flags].plot.barh(ax=ax)

    ax.set(
        title="Ilk 10 bayrak: yillik av saati",
        xlabel="Av saati",
        ylabel="Bayrak"
    )

    ax.grid(axis="x", alpha=0.25)
    fig.tight_layout()
    fig.savefig(
        OUTPUT_DIR / "top_flags_by_year.png",
        dpi=160
    )
    plt.close(fig)

    # Ilk 10 av araci
    gears = (
        main.groupby("geartype")["fishing_hours"]
        .sum()
        .nlargest(10)
        .sort_values()
    )

    fig, ax = plt.subplots(figsize=(10, 6))

    gears.plot.barh(ax=ax, color="#087e8b")

    ax.set(
        title="Av araci turune gore av saati",
        xlabel="Av saati",
        ylabel="Av araci"
    )

    ax.grid(axis="x", alpha=0.25)
    fig.tight_layout()
    fig.savefig(
        OUTPUT_DIR / "top_gear_types.png",
        dpi=160
    )
    plt.close(fig)

    # Kalite raporu
    total_read = int(quality["rows_read"].sum())
    total_used = int(quality["rows_used"].sum())

    print("\nVERI KALITE RAPORU")
    print(quality.to_string(index=False))

    print(f"\nOkunan satir: {total_read:,}")
    print(f"Kullanilan satir: {total_used:,}")
    print(f"Disarida birakilan satir: {total_read-total_used:,}")

    anomalies = int(quality["fishing_gt_ais_rows"].sum())

    if anomalies > 0:
        print(
            f"\nUYARI: fishing_hours > hours olan "
            f"{anomalies:,} satir var. "
            "Bu satirlar otomatik silinmedi."
        )

    print(
        "\nToplam av saati:",
        f"{main['fishing_hours'].sum():,.0f}"
    )

    print(f"\nSonuclar: {OUTPUT_DIR}")


def main():

    files = find_monthly_files()

    main, grid, quality = aggregate_data(files)

    save_outputs(main, grid, quality)


if __name__ == "__main__":
    main()
