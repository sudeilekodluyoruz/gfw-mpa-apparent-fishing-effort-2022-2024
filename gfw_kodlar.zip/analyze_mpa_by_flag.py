"""CHN ve UNKNOWN-CHN için MPA örtüşme analizi.

Ham GFW aylık CSV'lerini kullanır; 0.1° hücre çözünürlüğünü korur.
Önceki analyze_mpa_overlap.py dosyasını değiştirmez.
"""
from __future__ import annotations

import time
from pathlib import Path

import duckdb
import geopandas as gpd
import matplotlib
import numpy as np
import pandas as pd
import shapely

matplotlib.use("Agg")
import matplotlib.pyplot as plt

PROJECT_DIR = Path(__file__).resolve().parent
MPA_FILE = PROJECT_DIR / "data" / "wdpca" / "marine_coastal_protected_areas.geojson"
OUTPUT_DIR = PROJECT_DIR / "outputs" / "mpa_analizi"

CELL_DEGREES = 0.1
NEAR_BUFFER_DEGREES = 0.2
EARTH_RADIUS_KM = 6371.0088
FLAGS = ["CHN", "UNKNOWN-CHN"]

ZONE_NO_TAKE = "Inside no-take MPA"
ZONE_INSIDE = "Inside other MPA"
ZONE_NEAR = "Near MPA (0.2 degree)"
ZONE_OUTSIDE = "Outside MPA vicinity"
ZONE_ORDER = [ZONE_NO_TAKE, ZONE_INSIDE, ZONE_NEAR, ZONE_OUTSIDE]


def read_effort() -> pd.DataFrame:
    files = sorted(PROJECT_DIR.rglob("fleet-monthly-csvs-10-v3-20??-??-??.csv"))
    if not files:
        raise FileNotFoundError("2022–2024 aylık GFW CSV dosyaları bulunamadı.")
    paths_sql = "[" + ",".join(
        "'" + p.resolve().as_posix().replace("'", "''") + "'" for p in files
    ) + "]"
    query = f"""
        SELECT
            CAST(year AS INTEGER) AS year,
            UPPER(TRIM(COALESCE(flag, 'UNKNOWN'))) AS flag,
            cell_ll_lat,
            cell_ll_lon,
            SUM(fishing_hours) AS fishing_hours,
            SUM(hours) AS ais_hours
        FROM read_csv({paths_sql}, union_by_name=true)
        WHERE UPPER(TRIM(COALESCE(flag, 'UNKNOWN'))) IN ('CHN', 'UNKNOWN-CHN')
        GROUP BY 1, 2, 3, 4
    """
    print(f"{len(files)} aylık CSV okunuyor; yalnızca CHN ve UNKNOWN-CHN...", flush=True)
    with duckdb.connect() as con:
        df = con.execute(query).df()
    if df.empty:
        raise RuntimeError("CHN veya UNKNOWN-CHN kaydı bulunamadı. CSV bayrak değerlerini kontrol edin.")
    df["year"] = df["year"].astype(int)
    print(f"Bayrak-hücre-yıl kayıtları: {len(df):,}", flush=True)
    return df


def load_areas() -> gpd.GeoDataFrame:
    if not MPA_FILE.exists():
        raise FileNotFoundError(f"MPA sınır dosyası bulunamadı: {MPA_FILE}")
    areas = gpd.read_file(MPA_FILE)
    areas = areas.loc[
        areas["site_type"].eq("PA") & areas["realm"].eq("Marine")
    ].copy()
    areas = areas.loc[~areas["status"].isin(["Proposed"])].copy()
    areas["status_yr"] = pd.to_numeric(areas["status_yr"], errors="coerce")
    areas.loc[areas["status_yr"] <= 0, "status_yr"] = np.nan
    areas["no_take"] = areas["no_take"].fillna("Not Reported")
    areas = areas.loc[areas.geometry.notna() & ~areas.geometry.is_empty].copy()
    areas["geometry"] = areas.geometry.make_valid()
    if areas.empty:
        raise RuntimeError("Uygun Marine PA poligonu bulunamadı.")
    return areas


def cell_area_km2(lat_lower: np.ndarray) -> np.ndarray:
    lat1 = np.radians(lat_lower)
    lat2 = np.radians(lat_lower + CELL_DEGREES)
    dlon = np.radians(CELL_DEGREES)
    return EARTH_RADIUS_KM**2 * dlon * (np.sin(lat2) - np.sin(lat1))


def classify_unique_cells(rows: pd.DataFrame, areas: gpd.GeoDataFrame, year: int) -> pd.DataFrame:
    active = areas.loc[areas["status_yr"].notna() & areas["status_yr"].le(year)]
    if active.empty:
        raise RuntimeError(f"{year} için kuruluş yılı bilinen aktif MPA bulunamadı.")

    lon = rows["cell_ll_lon"].to_numpy(dtype=float) + CELL_DEGREES / 2
    lat = rows["cell_ll_lat"].to_numpy(dtype=float) + CELL_DEGREES / 2
    points = shapely.points(lon, lat)

    tree = shapely.STRtree(active.geometry.to_numpy())
    no_take = active["no_take"].eq("All").to_numpy()

    point_idx, area_idx = tree.query(points, predicate="covered_by")
    inside_any = np.zeros(len(points), dtype=bool)
    inside_any[point_idx] = True
    inside_no_take = np.zeros(len(points), dtype=bool)
    inside_no_take[point_idx[no_take[area_idx]]] = True

    near = np.zeros(len(points), dtype=bool)
    outside_idx = np.flatnonzero(~inside_any)
    if len(outside_idx):
        near_idx, _ = tree.query(
            points[outside_idx], predicate="dwithin", distance=NEAR_BUFFER_DEGREES
        )
        near[outside_idx[near_idx]] = True

    result = rows.copy()
    result["zone"] = np.select(
        [inside_no_take, inside_any, near],
        [ZONE_NO_TAKE, ZONE_INSIDE, ZONE_NEAR],
        default=ZONE_OUTSIDE,
    )
    return result


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    areas = load_areas()
    effort = read_effort()

    classified_parts = []
    for year in sorted(effort["year"].unique()):
        year_effort = effort.loc[effort["year"].eq(year)].copy()
        unique_cells = year_effort[["cell_ll_lat", "cell_ll_lon"]].drop_duplicates()
        print(
            f"{year}: {len(unique_cells):,} benzersiz 0.1° hücre MPA alanlarıyla eşleştiriliyor...",
            flush=True,
        )
        t0 = time.time()
        cell_zones = classify_unique_cells(unique_cells, areas, int(year))
        classified_parts.append(year_effort.merge(
            cell_zones, on=["cell_ll_lat", "cell_ll_lon"], how="left", validate="many_to_one"
        ))
        print(f"  Tamamlandı ({time.time() - t0:.1f} sn)", flush=True)

    classified = pd.concat(classified_parts, ignore_index=True)
    summary = (
        classified.groupby(["year", "flag", "zone"], as_index=False)
        .agg(
            visited_cells=("cell_ll_lat", "size"),
            fishing_hours=("fishing_hours", "sum"),
            ais_hours=("ais_hours", "sum"),
            avg_fishing_hours_per_cell=("fishing_hours", "mean"),
            median_fishing_hours_per_cell=("fishing_hours", "median"),
        )
    )
    summary["fishing_share_of_ais_hours_pct"] = (
        summary["fishing_hours"] / summary["ais_hours"] * 100
    )
    summary["fishing_share_of_flag_year_pct"] = (
        summary["fishing_hours"]
        / summary.groupby(["year", "flag"])["fishing_hours"].transform("sum") * 100
    )
    summary["zone"] = pd.Categorical(summary["zone"], categories=ZONE_ORDER, ordered=True)
    summary = summary.sort_values(["flag", "year", "zone"]).reset_index(drop=True)
    summary.to_csv(OUTPUT_DIR / "flag_mpa_effort_by_year.csv", index=False)

    inside = classified.loc[classified["zone"].isin([ZONE_NO_TAKE, ZONE_INSIDE])].copy()
    inside.to_csv(OUTPUT_DIR / "flag_mpa_inside_cells.csv", index=False)

    # Her bayrak için ayrı grafik; bölgeler AIS saatine göre balıkçılık payını gösterir.
    for flag in FLAGS:
        part = summary.loc[summary["flag"].eq(flag)].copy()
        if part.empty:
            continue
        chart = part.pivot(index="year", columns="zone", values="fishing_share_of_ais_hours_pct")
        chart = chart[[z for z in ZONE_ORDER if z in chart.columns]]
        ax = chart.plot(marker="o", figsize=(10, 6))
        ax.set_title(f"{flag}: Fishing share of observed AIS hours by MPA zone")
        ax.set_xlabel("Year")
        ax.set_ylabel("Fishing hours / AIS presence hours (%)")
        ax.set_xticks(chart.index)
        ax.grid(alpha=0.25)
        plt.tight_layout()
        safe_flag = flag.lower().replace("-", "_")
        plt.savefig(OUTPUT_DIR / f"{safe_flag}_mpa_comparison.png", dpi=160)
        plt.close()

    print("\nCHN / UNKNOWN-CHN MPA analizi tamamlandı.")
    print(summary[[
        "year", "flag", "zone", "visited_cells", "fishing_hours",
        "fishing_share_of_ais_hours_pct", "fishing_share_of_flag_year_pct"
    ]].to_string(index=False))
    print(f"\nKullanılan Marine PA kaydı: {len(areas):,}")
    print(f"Kuruluş yılı bilinmeyen alan: {int(areas['status_yr'].isna().sum()):,} (ilgili yıl sınıflamasına dahil edilmez)")
    print(f"Sonuçlar: {OUTPUT_DIR}")
    print("UYARI: MPA içinde görülen AIS temelli apparent fishing effort tek başına ihlal kanıtı değildir.")
    print("Yakınlık tamponu 0.2 derece koordinattır; sabit bir kilometre mesafesi değildir.")


if __name__ == "__main__":
    main()
