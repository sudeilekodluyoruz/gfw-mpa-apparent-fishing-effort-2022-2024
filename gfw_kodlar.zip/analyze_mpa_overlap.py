"""GFW görünür balıkçılık eforunu deniz koruma alanlarının (MPA) içinde ve yakınında karşılaştırır.

Önce `python download_mpas.py` ile sınırları indirin, sonra bu dosyayı çalıştırın.
Hızlı deneme için tek yıl: `python analyze_mpa_overlap.py 2024`
Gereken paketler: duckdb geopandas shapely pandas numpy matplotlib (geopandas >= 1.0 önerilir)

Yorum notları:
- Bir hücre, merkez noktası alanın içindeyse "içeride" sayılır (0,1° hücre = yaklaşık 11 km).
- Veri yalnızca AIS yayını yapan gemileri kapsar; "içeride balıkçılık var" ifadesi
  kural ihlali kanıtı değildir (geçiş, yanlış tespit, izinli faaliyet olabilir).
- "visited_cells" metriği yalnızca en az bir geminin göründüğü hücreleri kapsar;
  alanın tamamının yoğunluğu değildir.
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

import duckdb
import geopandas as gpd
import matplotlib
import numpy as np
import pandas as pd
import shapely

matplotlib.use("Agg")

import matplotlib.pyplot as plt


PROJECT_DIR = Path(__file__).resolve().parent
DATA_DIR = PROJECT_DIR / "data" / "wdpca"
MPA_FILE = DATA_DIR / "marine_coastal_protected_areas.geojson"
OUTPUT_DIR = PROJECT_DIR / "outputs"
NEAR_BUFFER_DEGREES = 0.2
CELL_DEGREES = 0.1
EARTH_RADIUS_KM = 6371.0088

# "Coastal" kıyıdaki karasal koruma alanlarını da içerir; deniz korumasıyla karışmasın
# diye varsayılan olarak yalnızca "Marine" kullanılır.
REALMS = ["Marine"]

ZONE_NO_TAKE = "Inside no-take MPA"
ZONE_INSIDE = "Inside other MPA"
ZONE_NEAR = "Near MPA (0.2° buffer)"
ZONE_OUTSIDE = "Outside MPA vicinity"
ZONE_ORDER = [ZONE_NO_TAKE, ZONE_INSIDE, ZONE_NEAR, ZONE_OUTSIDE]


def read_effort_by_cell_year() -> pd.DataFrame:
    files = sorted(PROJECT_DIR.rglob("fleet-monthly-csvs-10-v3-20??-??-??.csv"))
    if not files:
        raise FileNotFoundError("2022–2024 aylık GFW CSV dosyaları bulunamadı.")

    paths_sql = "[" + ",".join(
        "'" + path.resolve().as_posix().replace("'", "''") + "'" for path in files
    ) + "]"
    query = f"""
        SELECT
            year,
            cell_ll_lat,
            cell_ll_lon,
            SUM(fishing_hours) AS fishing_hours,
            SUM(hours) AS ais_hours
        FROM read_csv({paths_sql}, union_by_name=true)
        GROUP BY year, cell_ll_lat, cell_ll_lon
    """
    print(f"{len(files)} CSV okunuyor (36 bekleniyor)...")
    with duckdb.connect() as connection:
        frame = connection.execute(query).df()
    return frame


def cell_area_km2(lat_lower: np.ndarray) -> np.ndarray:
    """Spherical area of each 0.1° cell using its lower and upper latitude."""
    lat_1 = np.radians(lat_lower)
    lat_2 = np.radians(lat_lower + CELL_DEGREES)
    delta_lon = np.radians(CELL_DEGREES)
    return EARTH_RADIUS_KM**2 * delta_lon * (np.sin(lat_2) - np.sin(lat_1))


def load_protected_areas() -> gpd.GeoDataFrame:
    if not MPA_FILE.exists():
        raise FileNotFoundError(
            "Koruma alanı sınırları bulunamadı. Önce `python download_mpas.py` çalıştırın."
        )
    areas = gpd.read_file(MPA_FILE)
    areas = areas.loc[
        areas["site_type"].eq("PA") & areas["realm"].isin(REALMS)
    ].copy()

    # Önerilmiş (henüz yürürlükte olmayan) alanlar koruma sayılmaz.
    areas = areas.loc[~areas["status"].isin(["Proposed"])].copy()

    # WDPA'da bilinmeyen kuruluş yılı çoğu zaman 0 olarak gelir; 0 <= 2022 olduğu için
    # bu alanlar yanlışlıkla "korunuyor" sayılırdı. 0 ve negatifleri bilinmeyen yap.
    areas["status_yr"] = pd.to_numeric(areas["status_yr"], errors="coerce")
    areas.loc[areas["status_yr"] <= 0, "status_yr"] = np.nan

    areas["no_take"] = areas["no_take"].fillna("Not Reported")
    areas = areas.loc[areas.geometry.notna() & ~areas.geometry.is_empty].copy()
    areas["geometry"] = areas.geometry.make_valid()
    if areas.empty:
        raise RuntimeError("Dosyada uygun deniz koruma alanı poligonu bulunamadı.")
    return areas


def classify_year(
    rows: pd.DataFrame, areas: gpd.GeoDataFrame, year: int
) -> pd.DataFrame:
    # Gözlem yılını kesme noktası olarak kullan: sonradan ilan edilen alanlar önceki
    # yıllarda korumalı sayılmaz. Kuruluş yılı bilinmeyenler dışarıda bırakılır.
    active = areas.loc[areas["status_yr"].notna() & areas["status_yr"].le(year)]
    if active.empty:
        raise RuntimeError(f"{year} yılı için kuruluş yılı bilinen MPA bulunamadı.")
    print(f"  {year}: {len(active):,} aktif alan, {int(active['no_take'].eq('All').sum()):,} tam av yasaklı, "
          f"{len(rows):,} hücre eşleştiriliyor", flush=True)
    t0 = time.time()

    lon = rows["cell_ll_lon"].to_numpy(dtype=float) + CELL_DEGREES / 2
    lat = rows["cell_ll_lat"].to_numpy(dtype=float) + CELL_DEGREES / 2
    points = shapely.points(lon, lat)

    # Dev bir birleşim/tampon poligonu yerine STRtree kullan: her nokta yalnızca
    # kendi çevresindeki birkaç alanla karşılaştırılır (çok daha hızlı ve az bellek).
    tree = shapely.STRtree(active.geometry.to_numpy())
    is_no_take = active["no_take"].eq("All").to_numpy()

    point_idx, area_idx = tree.query(points, predicate="covered_by")
    inside_any = np.zeros(len(points), dtype=bool)
    inside_any[point_idx] = True
    inside_no_take = np.zeros(len(points), dtype=bool)
    inside_no_take[point_idx[is_no_take[area_idx]]] = True
    print(f"    içeride: {inside_any.sum():,} hücre ({time.time() - t0:.0f} sn)", flush=True)

    near = np.zeros(len(points), dtype=bool)
    outside_idx = np.flatnonzero(~inside_any)
    near_point_idx, _ = tree.query(
        points[outside_idx], predicate="dwithin", distance=NEAR_BUFFER_DEGREES
    )
    near[outside_idx[near_point_idx]] = True
    print(f"    yakınında: {near.sum():,} hücre ({time.time() - t0:.0f} sn)", flush=True)

    result = rows.copy()
    result["zone"] = np.select(
        [inside_no_take, inside_any, near],
        [ZONE_NO_TAKE, ZONE_INSIDE, ZONE_NEAR],
        default=ZONE_OUTSIDE,
    )
    result["cell_area_km2"] = cell_area_km2(result["cell_ll_lat"].to_numpy(dtype=float))
    return result


def summarize(classified: pd.DataFrame) -> pd.DataFrame:
    summary = (
        classified.groupby(["year", "zone"], as_index=False)
        .agg(
            visited_cells=("fishing_hours", "size"),
            fishing_hours=("fishing_hours", "sum"),
            ais_hours=("ais_hours", "sum"),
            avg_fishing_hours_per_visited_cell=("fishing_hours", "mean"),
            median_fishing_hours_per_visited_cell=("fishing_hours", "median"),
            visited_cell_area_km2=("cell_area_km2", "sum"),
        )
    )
    summary["zone"] = pd.Categorical(summary["zone"], categories=ZONE_ORDER, ordered=True)
    summary = summary.sort_values(["year", "zone"]).reset_index(drop=True)
    summary["fishing_share_of_ais_hours_pct"] = (
        summary["fishing_hours"] / summary["ais_hours"] * 100
    )
    summary["fishing_share_of_year_total_pct"] = (
        summary["fishing_hours"]
        / summary.groupby("year")["fishing_hours"].transform("sum")
        * 100
    )
    # Yalnızca gemi görülen hücreler paydada; alanın tamamının yoğunluğu DEĞİLDİR.
    summary["fishing_hours_per_1000_km2_visited_cells"] = (
        summary["fishing_hours"] / summary["visited_cell_area_km2"] * 1000
    )
    return summary


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    areas = load_protected_areas()
    effort = read_effort_by_cell_year()

    all_years = sorted(effort["year"].dropna().astype(int).unique())
    # Örnek: `python analyze_mpa_overlap.py 2024` yalnızca 2024'ü çalıştırır (hızlı deneme için).
    years = [int(a) for a in sys.argv[1:]] or all_years
    print(f"Hücreler koruma alanlarıyla eşleştiriliyor: {years}", flush=True)
    classified = pd.concat(
        [classify_year(effort.loc[effort["year"].eq(year)], areas, year) for year in years],
        ignore_index=True,
    )
    summary = summarize(classified)

    summary.to_csv(OUTPUT_DIR / "mpa_effort_by_year.csv", index=False)
    # Tüm hücreleri değil, yalnızca koruma alanı İÇİNDEKİ hücreleri kaydet (dosya küçük kalır).
    inside = classified.loc[classified["zone"].isin([ZONE_NO_TAKE, ZONE_INSIDE])]
    inside.to_csv(OUTPUT_DIR / "mpa_inside_cells.csv", index=False)

    chart = summary.pivot(index="year", columns="zone", values="fishing_share_of_ais_hours_pct")
    chart = chart[[z for z in ZONE_ORDER if z in chart.columns]]
    chart.plot(marker="o", figsize=(10, 6))
    plt.title("Fishing share of observed AIS hours by MPA proximity")
    plt.xlabel("Year")
    plt.ylabel("Fishing hours / AIS presence hours (%)")
    plt.xticks(chart.index)
    plt.grid(alpha=0.25)
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "mpa_effort_comparison.png", dpi=160)
    plt.close()

    unknown_year = int(areas["status_yr"].isna().sum())
    print("\nKoruma alanı karşılaştırması tamamlandı.")
    print(summary[["year", "zone", "visited_cells", "fishing_hours",
                   "fishing_share_of_ais_hours_pct",
                   "fishing_share_of_year_total_pct"]].round(2).to_string(index=False))
    print(f"\nKullanılan alan sayısı (Marine PA, Proposed hariç): {len(areas):,}")
    print(f"Kuruluş yılı bilinmeyen, analiz dışında kalan alanlar: {unknown_year:,}")
    print("Yakınlık tanımı: yaklaşık 0.2° koordinat tamponu; km karşılığı enleme göre değişir.")
    print(f"Sonuçlar: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
