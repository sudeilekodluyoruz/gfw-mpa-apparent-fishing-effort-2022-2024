"""Download official marine/coastal protected-area polygons from UNEP-WCMC."""

from __future__ import annotations

import json
from datetime import date
from pathlib import Path

import requests


PROJECT_DIR = Path(__file__).resolve().parent
DATA_DIR = PROJECT_DIR / "data" / "wdpca"
OUTPUT_FILE = DATA_DIR / "marine_coastal_protected_areas.geojson"
METADATA_FILE = DATA_DIR / "source.txt"
QUERY_URL = (
    "https://data-gis.unep-wcmc.org/server/rest/services/"
    "ProtectedPlanet/WDPCA/FeatureServer/1/query"
)
PAGE_SIZE = 1000


def main() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    params = {
        "where": "site_type = 'PA' AND realm IN ('Marine', 'Coastal')",
        "outFields": (
            "site_id,site_pid,site_type,name_eng,name,desig_eng,realm,"
            "iucn_cat,no_take,status,status_yr,iso3"
        ),
        "returnGeometry": "true",
        "outSR": "4326",
        # The GFW observations use 0.1° cells; this keeps the boundary file compact
        # while preserving substantially finer detail than the effort grid.
        "maxAllowableOffset": 0.005,
        "f": "geojson",
        "resultRecordCount": PAGE_SIZE,
    }

    total = 0
    offset = 0
    session = requests.Session()
    session.headers.update({"User-Agent": "GFW-MPA-Portfolio-Analysis/1.0"})
    with OUTPUT_FILE.open("w", encoding="utf-8") as output:
        output.write('{"type":"FeatureCollection","features":[\n')
        while True:
            params["resultOffset"] = offset
            response = session.get(QUERY_URL, params=params, timeout=180)
            response.raise_for_status()
            payload = response.json()
            if "error" in payload:
                raise RuntimeError(f"WDPCA API error: {payload['error']}")

            features = payload.get("features", [])
            if not features:
                break
            for feature in features:
                if total:
                    output.write(",\n")
                json.dump(feature, output, ensure_ascii=False, separators=(",", ":"))
                total += 1

            print(f"İndirilen sınır kaydı: {total}")
            offset += len(features)
            if len(features) < PAGE_SIZE and not payload.get("exceededTransferLimit", False):
                break

        output.write('\n]}\n')

    if total == 0:
        OUTPUT_FILE.unlink(missing_ok=True)
        raise RuntimeError("WDPCA sorgusu hiç korunan alan döndürmedi.")

    METADATA_FILE.write_text(
        "Source: UNEP-WCMC and IUCN, World Database on Protected and Conserved Areas (WDPCA)\n"
        "Layer: WDPCA_poly_latest, site_type=PA, realm=Marine or Coastal\n"
        f"Downloaded: {date.today().isoformat()}\n"
        "Service: https://data-gis.unep-wcmc.org/server/rest/services/ProtectedPlanet/WDPCA/FeatureServer\n"
        "Geometry generalization: maxAllowableOffset=0.005 degrees (WGS84)\n"
        "Use: non-commercial only; see https://www.unep-wcmc.org/en/wdpa-data-license\n",
        encoding="utf-8",
    )
    print(f"Tamamlandı: {total:,} sınır kaydı → {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
