# Global Fishing Watch: apparent fishing effort

Starter analysis for the monthly AIS apparent fishing effort data (2022–2024).
The script reads the monthly CSVs in chunks, so it does not load all raw rows
into memory at once.

## Setup and run

The year folders are already extracted in this project. The virtual environment
is `.venv`; install dependencies from the VS Code terminal with:

```bash
python -m pip install -r requirements.txt
```

Run the starter report with:

```bash
python gfw_hazirlik.py
```

`gfw_duckdb_taslak.py` is a separate SQL-based exploration script. Run it with
`python gfw_duckdb_taslak.py` to print quick aggregate summaries.

## Marine protected area comparison

Download the current marine and coastal protected-area polygons from the
UNEP-WCMC/IUCN WDPCA feature service, then run the spatial comparison:

```bash
python download_mpas.py
python analyze_mpa_overlap.py
```

The comparison uses only protected areas (`PA`), not OECMs, and includes areas
whose recorded designation year is no later than the GFW observation year. GFW
cell centers are used for the point-in-polygon match. The nearby category is an
approximate 0.2° coordinate buffer; its ground distance varies with latitude.
The downloaded polygon boundaries are generalized to 0.005° to keep the file
manageable relative to the 0.1° GFW analysis grid.
The outputs describe cells with observed fishing-vessel AIS activity, not every
ocean cell, and must not be read as proof that an MPA is or is not effective.

Source attribution: UNEP-WCMC and IUCN, World Database on Protected and Conserved
Areas (WDPCA), downloaded date and exact service URL are recorded in
`data/wdpca/source.txt`. The WDPCA data are for non-commercial use only; check
the official [data license](https://www.unep-wcmc.org/en/wdpa-data-license)
before publishing or reusing derived work.

The script writes monthly totals, flag and gear summaries, the top 100 grid-cell
hotspots, and two PNG charts into `outputs/`.

`fishing_hours` is an AIS-derived estimate of apparent fishing effort. It is not
an exact count of all fishing activity or a direct measure of catch.
