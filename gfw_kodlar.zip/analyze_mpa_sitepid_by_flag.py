"""WDPCA site_pid bazında CHN ve UNKNOWN-CHN MPA analizi."""

from __future__ import annotations

import time
from pathlib import Path

import duckdb
import geopandas as gpd
import numpy as np
import pandas as pd
import shapely

PROJECT_DIR = Path(__file__).resolve().parent
MPA_FILE = PROJECT_DIR / "data" / "wdpca" / "marine_coastal_protected_areas.geojson"
OUTPUT_DIR = PROJECT_DIR / "outputs" / "mpa_analizi" / "site_bazinda"

CELL_DEGREES = 0.1
FLAGS = ["CHN", "UNKNOWN-CHN"]


def read_effort() -> pd.DataFrame:
    files = sorted(
        PROJECT_DIR.rglob("fleet-monthly-csvs-10-v3-20??-??-??.csv")
    )

    if not files:
        raise FileNotFoundError("2022-2024 aylık GFW CSV dosyaları bulunamadı.")

    paths_sql = "[" + ",".join(
        "'" + p.resolve().as_posix().replace("'", "''") + "'"
        for p in files
    ) + "]"

    query = f"""
        SELECT
            CAST(year AS INTEGER) AS year,
            UPPER(TRIM(COALESCE(flag, 'UNKNOWN'))) AS flag,
            cell_ll_lat,
            cell_ll_lon,
            SUM(fishing_hours) AS fishing_hours,
            SUM(hours) AS ais_hours
        FROM read_csv({paths_sql}, union_by_name=true)
        WHERE UPPER(TRIM(COALESCE(flag, 'UNKNOWN')))
              IN ('CHN', 'UNKNOWN-CHN')
        GROUP BY 1, 2, 3, 4
    """

    print(f"{len(files)} aylık CSV okunuyor...", flush=True)

    with duckdb.connect() as con:
        effort = con.execute(query).df()

    if effort.empty:
        raise RuntimeError("CHN veya UNKNOWN-CHN kaydı bulunamadı.")

    effort["year"] = effort["year"].astype(int)

    print(f"Bayrak-hücre-yıl kayıtları: {len(effort):,}", flush=True)

    return effort


def load_areas() -> gpd.GeoDataFrame:
    if not MPA_FILE.exists():
        raise FileNotFoundError(f"MPA dosyası bulunamadı: {MPA_FILE}")

    areas = gpd.read_file(MPA_FILE)

    required = [
        "site_id",
        "site_pid",
        "name_eng",
        "desig_eng",
        "iucn_cat",
        "no_take",
        "status",
        "status_yr",
        "site_type",
        "realm",
        "iso3",
    ]

    missing = [c for c in required if c not in areas.columns]

    if missing:
        raise ValueError(f"GeoJSON içinde eksik sütunlar: {missing}")

    areas = areas.loc[
        areas["site_type"].eq("PA")
        & areas["realm"].eq("Marine")
    ].copy()

    areas = areas.loc[
        ~areas["status"].isin(["Proposed"])
    ].copy()

    areas["site_pid"] = areas["site_pid"].astype("string").str.strip()

    if areas["site_pid"].isna().any():
        raise ValueError("Bazı MPA kayıtlarında site_pid eksik.")

    duplicated_pid = areas["site_pid"].duplicated(keep=False)

    if duplicated_pid.any():
        print("\nUYARI: Tekrarlanan site_pid değerleri bulundu:")
        print(
            areas.loc[
                duplicated_pid,
                ["site_id", "site_pid", "name_eng", "iucn_cat"]
            ].to_string(index=False)
        )
        raise ValueError(
            "site_pid benzersiz değil. Eşleştirme öncesinde incelenmeli."
        )

    areas["status_yr"] = pd.to_numeric(
        areas["status_yr"], errors="coerce"
    )

    areas.loc[areas["status_yr"] <= 0, "status_yr"] = np.nan

    areas["no_take"] = (
        areas["no_take"].fillna("Not Reported").astype(str)
    )

    areas["name_eng"] = (
        areas["name_eng"].fillna("Unnamed MPA").astype(str)
    )

    areas = areas.loc[
        areas.geometry.notna() & ~areas.geometry.is_empty
    ].copy()

    areas["geometry"] = areas.geometry.make_valid()

    areas = areas.loc[
        areas.geometry.notna() & ~areas.geometry.is_empty
    ].copy()

    if areas.empty:
        raise RuntimeError("Uygun Marine PA poligonu bulunamadı.")

    print(f"WDPCA Marine PA bileşeni: {len(areas):,}", flush=True)

    return areas


def match_cells_to_sites(
    cells: pd.DataFrame,
    active: gpd.GeoDataFrame
) -> pd.DataFrame:
    """Hücre merkezlerini ayrı site_pid geometrileriyle eşleştir."""

    lon = (
        cells["cell_ll_lon"].to_numpy(dtype=float)
        + CELL_DEGREES / 2
    )

    lat = (
        cells["cell_ll_lat"].to_numpy(dtype=float)
        + CELL_DEGREES / 2
    )

    points = shapely.points(lon, lat)

    tree = shapely.STRtree(active.geometry.to_numpy())

    point_idx, area_idx = tree.query(
        points,
        predicate="covered_by"
    )

    if len(point_idx) == 0:
        return pd.DataFrame(
            columns=[
                "cell_ll_lat",
                "cell_ll_lon",
                "site_id",
                "site_pid",
            ]
        )

    matched = cells.iloc[point_idx][
        ["cell_ll_lat", "cell_ll_lon"]
    ].reset_index(drop=True)

    site_cols = [
        "site_id",
        "site_pid",
        "name_eng",
        "desig_eng",
        "iucn_cat",
        "no_take",
        "status",
        "status_yr",
        "iso3",
    ]

    site_info = (
        active.iloc[area_idx][site_cols]
        .reset_index(drop=True)
    )

    return pd.concat([matched, site_info], axis=1)


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    areas = load_areas()
    effort = read_effort()

    all_matches = []

    for year in sorted(effort["year"].unique()):
        active = areas.loc[
            areas["status_yr"].notna()
            & areas["status_yr"].le(year)
        ].copy()

        year_effort = effort.loc[
            effort["year"].eq(year)
        ].copy()

        cells = (
            year_effort[
                ["cell_ll_lat", "cell_ll_lon"]
            ]
            .drop_duplicates()
            .reset_index(drop=True)
        )

        print(
            f"{year}: {len(cells):,} hücre, "
            f"{len(active):,} aktif bileşen eşleştiriliyor...",
            flush=True,
        )

        t0 = time.time()

        matches = match_cells_to_sites(cells, active)

        if matches.empty:
            print("  Eşleşme bulunamadı.")
            continue

        joined = matches.merge(
            year_effort,
            on=["cell_ll_lat", "cell_ll_lon"],
            how="inner",
            validate="many_to_many",
        )

        all_matches.append(joined)

        print(
            f"  {len(matches):,} hücre-bileşen eşleşmesi; "
            f"{time.time() - t0:.1f} saniye",
            flush=True,
        )

    if not all_matches:
        raise RuntimeError("Hiçbir MPA eşleşmesi bulunamadı.")

    detail = pd.concat(all_matches, ignore_index=True)

    detail_path = (
        OUTPUT_DIR / "mpa_sitepid_cell_flag_year_detail.csv"
    )

    detail.to_csv(detail_path, index=False)

    group_cols = [
        "year",
        "flag",
        "site_id",
        "site_pid",
        "name_eng",
        "desig_eng",
        "iucn_cat",
        "no_take",
        "status",
        "status_yr",
        "iso3",
    ]

    summary = (
        detail.groupby(
            group_cols,
            dropna=False,
            as_index=False
        )
        .agg(
            matched_cells=("cell_ll_lat", "size"),
            fishing_hours=("fishing_hours", "sum"),
            ais_hours=("ais_hours", "sum"),
        )
    )

    summary["fishing_share_of_ais_hours_pct"] = np.where(
        summary["ais_hours"] > 0,
        summary["fishing_hours"] / summary["ais_hours"] * 100,
        np.nan,
    )

    summary_path = (
        OUTPUT_DIR / "mpa_sitepid_flag_year_summary.csv"
    )

    summary.to_csv(summary_path, index=False)

    wide = summary.pivot_table(
        index=[
            "flag",
            "site_id",
            "site_pid",
            "name_eng",
            "desig_eng",
            "iucn_cat",
            "no_take",
            "iso3",
        ],
        columns="year",
        values="fishing_hours",
        aggfunc="sum",
    ).reset_index()

    wide.columns.name = None

    for year in [2022, 2023, 2024]:
        if year not in wide.columns:
            wide[year] = np.nan

    for a, b in [
        (2022, 2023),
        (2023, 2024),
        (2022, 2024),
    ]:
        valid = wide[a].notna() & wide[b].notna()

        wide[f"change_{a}_{b}_hours"] = np.where(
            valid,
            wide[b] - wide[a],
            np.nan,
        )

        wide[f"change_{a}_{b}_pct"] = np.where(
            valid & (wide[a] > 0),
            (wide[b] / wide[a] - 1) * 100,
            np.nan,
        )

    change_path = (
        OUTPUT_DIR / "mpa_sitepid_flag_year_change.csv"
    )

    wide.to_csv(change_path, index=False)

    print("\nSITE_PID BAZINDA ANALİZ TAMAMLANDI.")
    print(f"GeoJSON bileşeni: {len(areas):,}")
    print(f"Detay satırı: {len(detail):,}")
    print(f"Özet satırı: {len(summary):,}")
    print(f"Farklı site_pid: {summary['site_pid'].nunique():,}")

    print("\n2022-2024 DEĞİŞİMİNDE EN YÜKSEK 15 ARTIŞ:")

    for flag in FLAGS:
        part = wide.loc[
            wide["flag"].eq(flag)
            & wide["change_2022_2024_hours"].notna()
        ]

        top = part.sort_values(
            "change_2022_2024_hours",
            ascending=False,
        ).head(15)

        print(f"\n{flag}")

        cols = [
            "site_id",
            "site_pid",
            "name_eng",
            "iucn_cat",
            2022,
            2024,
            "change_2022_2024_hours",
            "change_2022_2024_pct",
        ]

        print(top[cols].round(2).to_string(index=False))

    print("\nKAYDEDİLEN DOSYALAR:")
    print(detail_path)
    print(summary_path)
    print(change_path)

    print(
        "\nUYARI: Hücre merkezleri poligonlarla eşleştirilmiştir; "
        "hücrenin tamamı MPA içinde olmak zorunda değildir."
    )

    print(
        "UYARI: Bir hücre birden fazla MPA bileşeniyle eşleşirse "
        "her bileşene ayrı atanır. Alan bazlı sonuçlar toplanırken "
        "çift sayım oluşabilir."
    )

    print(
        "UYARI: AIS temelli apparent fishing effort tek başına "
        "MPA ihlali kanıtı değildir."
    )


if __name__ == "__main__":
    main()
