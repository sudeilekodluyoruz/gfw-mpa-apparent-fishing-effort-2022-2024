"""CHN ve UNKNOWN-CHN için koruma alanı (MPA) bazında effort analizi.

Ham GFW aylık CSV'lerini ve UNEP-WCMC/IUCN WDPCA GeoJSON dosyasını kullanır.
Her 0.1 derece GFW hücresinin merkezini, ilgili yılda aktif Marine PA poligonlarıyla
karşılaştırır. Bir hücre birden fazla MPA ile eşleşirse her eşleşme ayrı MPA'ya
atanır; bu nedenle MPA bazındaki toplamlar üst üste binen alanlarda çift sayım içerebilir.
Önceki analiz dosyalarını değiştirmez.
"""
from __future__ import annotations

import time
from pathlib import Path

import duckdb
import geopandas as gpd
import numpy as np
import pandas as pd
import shapely

PROJECT_DIR = Path(__file__).resolve().parent
MPA_FILE = PROJECT_DIR / "data" / "wdpca" / "marine_coastal_protected_areas.geojson"
OUTPUT_DIR = PROJECT_DIR / "outputs" / "mpa_analizi" / "site_bazinda"
CELL_DEGREES = 0.1
FLAGS = ["CHN", "UNKNOWN-CHN"]


def read_effort() -> pd.DataFrame:
    files = sorted(PROJECT_DIR.rglob("fleet-monthly-csvs-10-v3-20??-??-??.csv"))
    if not files:
        raise FileNotFoundError("2022–2024 aylık GFW CSV dosyaları bulunamadı.")
    paths_sql = "[" + ",".join(
        "'" + p.resolve().as_posix().replace("'", "''") + "'" for p in files
    ) + "]"
    query = f"""
        SELECT CAST(year AS INTEGER) AS year,
               UPPER(TRIM(COALESCE(flag, 'UNKNOWN'))) AS flag,
               cell_ll_lat, cell_ll_lon,
               SUM(fishing_hours) AS fishing_hours,
               SUM(hours) AS ais_hours
        FROM read_csv({paths_sql}, union_by_name=true)
        WHERE UPPER(TRIM(COALESCE(flag, 'UNKNOWN'))) IN ('CHN', 'UNKNOWN-CHN')
        GROUP BY 1, 2, 3, 4
    """
    print(f"{len(files)} aylık CSV okunuyor; CHN ve UNKNOWN-CHN...", flush=True)
    with duckdb.connect() as con:
        effort = con.execute(query).df()
    if effort.empty:
        raise RuntimeError("CHN veya UNKNOWN-CHN kaydı bulunamadı.")
    effort["year"] = effort["year"].astype(int)
    print(f"Bayrak-hücre-yıl kayıtları: {len(effort):,}", flush=True)
    return effort


def load_areas() -> gpd.GeoDataFrame:
    if not MPA_FILE.exists():
        raise FileNotFoundError(f"MPA sınır dosyası bulunamadı: {MPA_FILE}")
    areas = gpd.read_file(MPA_FILE)
    required = ["site_id", "name_eng", "iucn_cat", "no_take", "status", "status_yr", "site_type", "realm"]
    missing = [c for c in required if c not in areas.columns]
    if missing:
        raise ValueError(f"GeoJSON içinde beklenen alanlar eksik: {missing}")
    areas = areas.loc[
        areas["site_type"].eq("PA") & areas["realm"].eq("Marine")
    ].copy()
    areas = areas.loc[~areas["status"].isin(["Proposed"])].copy()
    areas["status_yr"] = pd.to_numeric(areas["status_yr"], errors="coerce")
    areas.loc[areas["status_yr"] <= 0, "status_yr"] = np.nan
    areas["no_take"] = areas["no_take"].fillna("Not Reported").astype(str)
    areas["name_eng"] = areas["name_eng"].fillna("Unnamed MPA").astype(str)
    areas = areas.loc[areas.geometry.notna() & ~areas.geometry.is_empty].copy()
    areas["geometry"] = areas.geometry.make_valid()
    areas = areas.loc[areas.geometry.notna() & ~areas.geometry.is_empty].copy()
    if areas.empty:
        raise RuntimeError("Uygun Marine PA poligonu bulunamadı.")
    return areas


def match_cells_to_sites(cells: pd.DataFrame, active: gpd.GeoDataFrame) -> pd.DataFrame:
    """Hücre merkezlerini poligonlara eşleştir; bir hücre birden fazla MPA'ya girebilir."""
    lon = cells["cell_ll_lon"].to_numpy(dtype=float) + CELL_DEGREES / 2
    lat = cells["cell_ll_lat"].to_numpy(dtype=float) + CELL_DEGREES / 2
    points = shapely.points(lon, lat)
    tree = shapely.STRtree(active.geometry.to_numpy())
    point_idx, area_idx = tree.query(points, predicate="covered_by")
    if len(point_idx) == 0:
        return pd.DataFrame(columns=["cell_ll_lat", "cell_ll_lon", "site_id"])
    matched = cells.iloc[point_idx][["cell_ll_lat", "cell_ll_lon"]].reset_index(drop=True)
    site_cols = ["site_id", "name_eng", "desig_eng", "iucn_cat", "no_take", "status", "status_yr", "iso3"]
    site_info = active.iloc[area_idx][site_cols].reset_index(drop=True)
    return pd.concat([matched, site_info], axis=1)


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    areas = load_areas()
    effort = read_effort()
    all_matches = []

    for year in sorted(effort["year"].unique()):
        active = areas.loc[areas["status_yr"].notna() & areas["status_yr"].le(year)].copy()
        year_effort = effort.loc[effort["year"].eq(year)].copy()
        cells = year_effort[["cell_ll_lat", "cell_ll_lon"]].drop_duplicates().reset_index(drop=True)
        print(f"{year}: {len(cells):,} hücre, {len(active):,} aktif Marine PA ile eşleştiriliyor...", flush=True)
        t0 = time.time()
        matches = match_cells_to_sites(cells, active)
        if matches.empty:
            print("  Bu yılda MPA içinde eşleşen hücre bulunamadı.", flush=True)
            continue
        joined = matches.merge(
            year_effort,
            on=["cell_ll_lat", "cell_ll_lon"],
            how="inner",
            validate="many_to_many",
        )
        joined.insert(0, "year", int(year))
        all_matches.append(joined)
        print(f"  {len(matches):,} hücre-MPA eşleşmesi; {time.time()-t0:.1f} sn", flush=True)

    if not all_matches:
        raise RuntimeError("Hiçbir yılda MPA ile eşleşen CHN/UNKNOWN-CHN hücresi bulunamadı.")

    detail = pd.concat(all_matches, ignore_index=True)
    detail.to_csv(OUTPUT_DIR / "mpa_site_cell_flag_year_detail.csv", index=False)

    group_cols = ["year", "flag", "site_id", "name_eng", "desig_eng", "iucn_cat", "no_take", "status", "status_yr", "iso3"]
    summary = detail.groupby(group_cols, dropna=False, as_index=False).agg(
        matched_cells=("cell_ll_lat", "size"),
        fishing_hours=("fishing_hours", "sum"),
        ais_hours=("ais_hours", "sum"),
    )
    summary["fishing_share_of_ais_hours_pct"] = np.where(
        summary["ais_hours"] > 0, summary["fishing_hours"] / summary["ais_hours"] * 100, np.nan
    )
    summary.to_csv(OUTPUT_DIR / "mpa_site_flag_year_summary.csv", index=False)

    # Yıllar arası değişim: aynı MPA ve bayrak için eksik yıl sıfır kabul edilmez;
    # yalnızca gözlenen yıl çiftleri karşılaştırılır.
    wide = summary.pivot_table(
        index=["flag", "site_id", "name_eng", "desig_eng", "iucn_cat", "no_take", "iso3"],
        columns="year", values="fishing_hours", aggfunc="sum"
    ).reset_index()
    wide.columns.name = None
    for a, b in [(2022, 2023), (2023, 2024), (2022, 2024)]:
        if a in wide.columns and b in wide.columns:
            valid = wide[a].notna() & wide[b].notna()
            wide[f"change_{a}_{b}_hours"] = np.where(valid, wide[b] - wide[a], np.nan)
            wide[f"change_{a}_{b}_pct"] = np.where(valid & (wide[a] > 0), (wide[b] / wide[a] - 1) * 100, np.nan)
    wide.to_csv(OUTPUT_DIR / "mpa_site_flag_year_change.csv", index=False)

    print("\nMPA bazında analiz tamamlandı.")
    print(f"Aktif Marine PA havuzu (yılı bilinen/ bilinmeyen dahil): {len(areas):,}")
    print(f"Eşleşme detayı: {len(detail):,} satır")
    print(f"Özet: {len(summary):,} MPA-bayrak-yıl satırı")
    print("\n2022-2023 artışına göre ilk 15 MPA:")
    if "change_2022_2023_hours" in wide.columns:
        top = wide.sort_values("change_2022_2023_hours", ascending=False).head(15)
        show = [c for c in ["flag", "site_id", "name_eng", 2022, 2023, "change_2022_2023_hours", "change_2022_2023_pct"] if c in top.columns]
        print(top[show].to_string(index=False))
    print(f"\nÇıktı klasörü: {OUTPUT_DIR}")
    print("UYARI: Hücre merkezleri poligonla eşleştirilir; hücrenin tamamı MPA içinde olmak zorunda değildir.")
    print("UYARI: Bir hücre birden fazla MPA ile eşleşirse her MPA'ya ayrı yazılır; MPA toplamları toplanırken çift sayım olabilir.")
    print("UYARI: AIS temelli apparent fishing effort tek başına MPA ihlali kanıtı değildir.")


if __name__ == "__main__":
    main()
