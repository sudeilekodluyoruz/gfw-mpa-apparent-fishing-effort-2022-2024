"""Adım 4b: 2022→2023 sıçramasını yaratan bayrakların ayrıntılı incelemesi.

Her odak bayrak için: aylık seri, av aracı dağılımı, artışın coğrafi yoğunlaşması ve
değişim haritası. Ham CSV'leri bir kez daha tarar (birkaç dakika sürer).

Çıktı (outputs/): bayrak_aylik.csv, bayrak_gear.csv, bayrak_grid.csv,
                  bayrak_aylik_seri.png, bayrak_degisim_haritalari.png
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import SymLogNorm

PROJECT_DIR = Path(__file__).resolve().parent
OUT = PROJECT_DIR / "outputs"
FOCUS = ["CHN", "UNKNOWN-CHN", "VNM", "LKA", "SAU"]   # gfw_kalite.py çıktısındaki ilk bayraklar
BASE_YEAR, COMPARE_YEAR = 2022, 2023
COLUMNS = ["year", "month", "cell_ll_lat", "cell_ll_lon", "flag", "geartype",
           "hours", "fishing_hours"]
CHUNK_SIZE = 1_000_000
CMAP_CHANGE = "PiYG"
BACKGROUND = "#f3eef8"


def aggregate(files: list[Path]):
    monthly, gear, grid = [], [], []
    for n, path in enumerate(files, start=1):
        print(f"[{n}/{len(files)}] Okunuyor: {path.name}")
        for chunk in pd.read_csv(path, usecols=COLUMNS, chunksize=CHUNK_SIZE):
            chunk = chunk[chunk["flag"].isin(FOCUS)].copy()
            if chunk.empty:
                continue
            chunk["geartype"] = chunk["geartype"].fillna("Unknown")
            chunk["lat"] = chunk["cell_ll_lat"].floordiv(1).astype("int16")
            chunk["lon"] = chunk["cell_ll_lon"].floordiv(1).astype("int16")
            monthly.append(chunk.groupby(["flag", "year", "month"], as_index=False)[["hours", "fishing_hours"]].sum())
            gear.append(chunk.groupby(["flag", "year", "geartype"], as_index=False)["fishing_hours"].sum())
            grid.append(chunk.groupby(["flag", "year", "lat", "lon"], as_index=False)["fishing_hours"].sum())

    monthly = pd.concat(monthly).groupby(["flag", "year", "month"], as_index=False)[["hours", "fishing_hours"]].sum()
    gear = pd.concat(gear).groupby(["flag", "year", "geartype"], as_index=False)["fishing_hours"].sum()
    grid = pd.concat(grid).groupby(["flag", "year", "lat", "lon"], as_index=False)["fishing_hours"].sum()
    return monthly, gear, grid


def report(monthly: pd.DataFrame, gear: pd.DataFrame, grid: pd.DataFrame, y0: int, y1: int) -> None:
    for flag in FOCUS:
        m = monthly[monthly["flag"] == flag]
        if m.empty:
            continue
        fh = m.groupby("year")["fishing_hours"].sum()
        delta = fh.get(y1, 0) - fh.get(y0, 0)
        print(f"\n{'=' * 60}\n{flag}: {y0}={fh.get(y0, 0):,.0f}  {y1}={fh.get(y1, 0):,.0f}  Δ={delta:,.0f}")

        g = gear[gear["flag"] == flag].pivot_table(index="geartype", columns="year",
                                                   values="fishing_hours", aggfunc="sum", fill_value=0)
        if y0 in g.columns and y1 in g.columns:
            g["delta"] = g[y1] - g[y0]
            g["share_of_delta_pct"] = g["delta"] / delta * 100 if delta else np.nan
            print("  Av aracına göre artış (ilk 3):")
            print(g.sort_values("delta", ascending=False).head(3).round(1).to_string())

        c = grid[grid["flag"] == flag].pivot_table(index=["lat", "lon"], columns="year",
                                                   values="fishing_hours", aggfunc="sum", fill_value=0)
        if y0 in c.columns and y1 in c.columns:
            c["delta"] = c[y1] - c[y0]
            pos = c[c["delta"] > 0].sort_values("delta", ascending=False)
            total_pos = pos["delta"].sum()
            if total_pos > 0:
                print(f"  Pozitif artışın %{pos['delta'].head(20).sum() / total_pos * 100:.0f}'i "
                      f"en çok artan 20 hücrede (toplam {len(pos):,} hücre büyüdü).")
                print("  En çok artan 5 hücre (hücrenin güney-batı köşesi: enlem, boylam):")
                print(pos.head(5)[[y0, y1, "delta"]].round(0).to_string())


def plot_monthly(monthly: pd.DataFrame) -> None:
    fig, axes = plt.subplots(2, 3, figsize=(15, 8), sharex=True)
    for ax, flag in zip(axes.ravel(), FOCUS):
        m = monthly[monthly["flag"] == flag].pivot_table(index="month", columns="year",
                                                          values="fishing_hours", aggfunc="sum")
        m.plot(ax=ax, marker="o", linewidth=2)
        ax.set(title=flag, xlabel="Ay", ylabel="Av saati")
        ax.set_xticks(range(1, 13))
        ax.grid(alpha=0.25)
    for ax in axes.ravel()[len(FOCUS):]:
        ax.axis("off")
    fig.suptitle("Odak bayrakların aylık av saati", fontsize=14)
    fig.tight_layout()
    fig.savefig(OUT / "bayrak_aylik_seri.png", dpi=150)
    plt.close(fig)


def to_grid(frame: pd.DataFrame) -> np.ndarray:
    arr = np.zeros((180, 360))
    rows = frame["lat"].to_numpy(dtype=int) + 90
    cols = frame["lon"].to_numpy(dtype=int) + 180
    ok = (rows >= 0) & (rows < 180) & (cols >= 0) & (cols < 360)
    np.add.at(arr, (rows[ok], cols[ok]), frame["fishing_hours"].to_numpy()[ok])
    return arr


def plot_change_maps(grid: pd.DataFrame, y0: int, y1: int) -> None:
    fig, axes = plt.subplots(3, 2, figsize=(15, 16))
    for ax, flag in zip(axes.ravel(), FOCUS):
        gf = grid[grid["flag"] == flag]
        a0, a1 = to_grid(gf[gf["year"] == y0]), to_grid(gf[gf["year"] == y1])
        diff = a1 - a0
        mask = (a0 == 0) & (a1 == 0)
        if mask.all():
            ax.axis("off")
            continue
        rows, cols = np.where(~mask)
        lat0, lat1 = max(rows.min() - 90 - 5, -90), min(rows.max() - 90 + 6, 90)
        lon0, lon1 = max(cols.min() - 180 - 5, -180), min(cols.max() - 180 + 6, 180)
        limit = max(np.percentile(np.abs(diff[~mask]), 99), 100)
        ax.set_facecolor(BACKGROUND)
        im = ax.imshow(np.ma.masked_where(mask, diff), origin="lower", extent=[-180, 180, -90, 90],
                       norm=SymLogNorm(linthresh=50, vmin=-limit, vmax=limit),
                       cmap=CMAP_CHANGE, interpolation="nearest", aspect="auto")
        ax.set_xlim(lon0, lon1)
        ax.set_ylim(lat0, lat1)
        ax.set_title(f"{flag}: {y1} − {y0}")
        fig.colorbar(im, ax=ax, shrink=0.8, label="Δ av saati")
    for ax in axes.ravel()[len(FOCUS):]:
        ax.axis("off")
    fig.tight_layout()
    fig.savefig(OUT / "bayrak_degisim_haritalari.png", dpi=150)
    plt.close(fig)


def main() -> None:
    files = sorted(PROJECT_DIR.rglob("fleet-monthly-csvs-10-v3-20??-??-??.csv"))
    if not files:
        raise SystemExit("CSV dosyaları bulunamadı.")
    OUT.mkdir(parents=True, exist_ok=True)
    monthly, gear, grid = aggregate(files)
    monthly.to_csv(OUT / "bayrak_aylik.csv", index=False)
    gear.to_csv(OUT / "bayrak_gear.csv", index=False)
    grid.to_csv(OUT / "bayrak_grid.csv", index=False)

    years = sorted(monthly["year"].unique())
    y0 = BASE_YEAR if BASE_YEAR in years else years[0]
    y1 = COMPARE_YEAR if COMPARE_YEAR in years else years[1]
    report(monthly, gear, grid, y0, y1)
    plot_monthly(monthly)
    plot_change_maps(grid, y0, y1)
    print(f"\nKaydedildi: {OUT}")


if __name__ == "__main__":
    main()
