
#!/usr/bin/env python3
"""
Guangdong Nanpeng Archipelago Wetlands
CHN ve UNKNOWN-CHN için 2022-2024 aylık apparent fishing effort analizi.

Girdi: Proje ana dizinindeki fleet-monthly-csvs-10-v3-YYYY klasörleri.
Çıktı: outputs/mpa_analizi/site_bazinda/guangdong_aylik/
"""

from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "outputs" / "mpa_analizi" / "site_bazinda" / "guangdong_aylik"
OUT.mkdir(parents=True, exist_ok=True)

CELLS = [(23.2, 117.1), (23.2, 117.2), (23.3, 117.2)]
FLAGS = ["CHN", "UNKNOWN-CHN"]
YEARS = [2022, 2023, 2024]

USECOLS = [
    "date", "year", "month", "cell_ll_lat", "cell_ll_lon",
    "flag", "hours", "fishing_hours"
]


def main():
    records = []
    files_found = 0

    # 1. Üç yılın 36 aylık CSV dosyasını oku.
    for year in YEARS:
        folder = ROOT / f"fleet-monthly-csvs-10-v3-{year}"
        files = sorted(
            folder.glob(f"fleet-monthly-csvs-10-v3-{year}-*.csv")
        )

        if len(files) != 12:
            raise FileNotFoundError(
                f"{folder} içinde 12 aylık CSV bekleniyordu; "
                f"{len(files)} bulundu."
            )

        for file in files:
            files_found += 1
            print(f"Okunuyor: {file.name}", flush=True)

            month_rows = []

            for chunk in pd.read_csv(
                file,
                usecols=USECOLS,
                chunksize=750_000
            ):
                # İlgili bayrakları ve üç hücreyi seç.
                mask = (
                    chunk["flag"].isin(FLAGS)
                    & chunk["cell_ll_lat"].round(1).isin([23.2, 23.3])
                    & chunk["cell_ll_lon"].round(1).isin([117.1, 117.2])
                )

                chunk = chunk.loc[mask].copy()

                # Yalnızca hedef üç hücreyi bırak.
                chunk["cell_ll_lat"] = chunk["cell_ll_lat"].round(1)
                chunk["cell_ll_lon"] = chunk["cell_ll_lon"].round(1)

                chunk["cell_coords"] = list(
                    zip(chunk["cell_ll_lat"], chunk["cell_ll_lon"])
                )
                chunk = chunk[chunk["cell_coords"].isin(CELLS)]

                if not chunk.empty:
                    # Tarih türünü burada standartlaştır.
                    chunk["date"] = pd.to_datetime(
                        chunk["date"], errors="coerce"
                    )

                    chunk = chunk.dropna(subset=["date"])

                    if not chunk.empty:
                        grouped_chunk = chunk.groupby(
                            [
                                "year", "month", "date", "flag",
                                "cell_ll_lat", "cell_ll_lon"
                            ],
                            as_index=False
                        ).agg(
                            hours=("hours", "sum"),
                            fishing_hours=("fishing_hours", "sum")
                        )

                        month_rows.append(grouped_chunk)

            if month_rows:
                monthly = pd.concat(month_rows, ignore_index=True)

                monthly = monthly.groupby(
                    [
                        "year", "month", "date", "flag",
                        "cell_ll_lat", "cell_ll_lon"
                    ],
                    as_index=False
                )[["hours", "fishing_hours"]].sum()

                records.append(monthly)

    if files_found != 36:
        raise RuntimeError(
            f"36 dosya yerine {files_found} dosya işlendi."
        )

    if not records:
        raise RuntimeError(
            "Seçilen hücre ve bayraklar için hiç kayıt bulunamadı."
        )

    # 2. Okunan kayıtları birleştir.
    raw = pd.concat(records, ignore_index=True)

    # Tarih türünü kesin olarak datetime yap.
    raw["date"] = pd.to_datetime(raw["date"])

    raw["cell"] = raw.apply(
        lambda r: (
            f'{r["cell_ll_lat"]:.1f}°N, '
            f'{r["cell_ll_lon"]:.1f}°E'
        ),
        axis=1
    )

    # 3. Eksik ay/hücre/bayrak kombinasyonlarını sıfırla tamamla.
    calendar = pd.date_range(
        "2022-01-01",
        "2024-12-01",
        freq="MS"
    )

    full = pd.MultiIndex.from_product(
        [calendar, FLAGS, CELLS],
        names=["date", "flag", "cell_coords"]
    ).to_frame(index=False)

    full["year"] = full["date"].dt.year
    full["month"] = full["date"].dt.month

    full["cell_ll_lat"] = full["cell_coords"].apply(
        lambda x: x[0]
    )
    full["cell_ll_lon"] = full["cell_coords"].apply(
        lambda x: x[1]
    )

    full = full.drop(columns="cell_coords")

    # 4. Tarih, bayrak ve koordinatlara göre birleştir.
    grouped = raw.groupby(
        ["date", "flag", "cell_ll_lat", "cell_ll_lon"],
        as_index=False
    )[["hours", "fishing_hours"]].sum()

    grouped["date"] = pd.to_datetime(grouped["date"])

    result = full.merge(
        grouped,
        on=["date", "flag", "cell_ll_lat", "cell_ll_lon"],
        how="left"
    )

    result[["hours", "fishing_hours"]] = (
        result[["hours", "fishing_hours"]].fillna(0)
    )

    result["cell"] = result.apply(
        lambda r: (
            f'{r["cell_ll_lat"]:.1f}°N, '
            f'{r["cell_ll_lon"]:.1f}°E'
        ),
        axis=1
    )

    result = result.sort_values(
        ["date", "flag", "cell_ll_lat", "cell_ll_lon"]
    )

    # 5. Bayrak bazında aylık toplamları hesapla.
    monthly_total = result.groupby(
        ["date", "year", "month", "flag"],
        as_index=False
    )[["hours", "fishing_hours"]].sum()

    # Sıfır saat olan aylarda oranı NaN bırak.
    monthly_total["fishing_share_of_ais_hours_pct"] = (
        monthly_total["fishing_hours"]
        .div(monthly_total["hours"].where(monthly_total["hours"] != 0))
        * 100
    )

    # 6. CSV çıktıları.
    result.to_csv(
        OUT / "guangdong_3_hucre_aylik_detay.csv",
        index=False,
        encoding="utf-8-sig"
    )

    monthly_total.to_csv(
        OUT / "guangdong_aylik_bayrak_toplam.csv",
        index=False,
        encoding="utf-8-sig"
    )

    # 7. Grafik 1: Bayrak başına aylık toplam zaman serisi.
    fig, axes = plt.subplots(
        2, 1,
        figsize=(14, 9),
        sharex=True,
        constrained_layout=True
    )

    for ax, flag in zip(axes, FLAGS):
        sub = monthly_total[
            monthly_total["flag"] == flag
        ].sort_values("date")

        ax.plot(
            sub["date"],
            sub["fishing_hours"],
            marker="o",
            markersize=3,
            linewidth=1.7
        )

        ax.set_title(flag)
        ax.set_ylabel("Fishing hours (saat)")
        ax.grid(True, linestyle=":", alpha=0.6)

    axes[-1].set_xlabel("Ay")

    fig.suptitle(
        "Guangdong Nanpeng – üç hücrede aylık apparent fishing effort",
        fontsize=14,
        fontweight="bold"
    )

    fig.savefig(
        OUT / "guangdong_aylik_zaman_serisi.png",
        dpi=220,
        bbox_inches="tight"
    )
    plt.close(fig)

    # 8. Grafik 2: Hücre bazında 36 aylık seri.
    fig, axes = plt.subplots(
        2, 1,
        figsize=(14, 10),
        sharex=True,
        constrained_layout=True
    )

    for ax, flag in zip(axes, FLAGS):
        sub = result[result["flag"] == flag]

        for cell, cell_df in sub.groupby("cell"):
            cell_df = cell_df.sort_values("date")

            ax.plot(
                cell_df["date"],
                cell_df["fishing_hours"],
                marker=".",
                markersize=3,
                linewidth=1.4,
                label=cell
            )

        ax.set_title(flag)
        ax.set_ylabel("Fishing hours (saat)")
        ax.grid(True, linestyle=":", alpha=0.6)
        ax.legend(title="0,1° hücre")

    axes[-1].set_xlabel("Ay")

    fig.suptitle(
        "Guangdong Nanpeng – hücre bazında aylık değişim",
        fontsize=14,
        fontweight="bold"
    )

    fig.savefig(
        OUT / "guangdong_aylik_hucre_grafigi.png",
        dpi=220,
        bbox_inches="tight"
    )
    plt.close(fig)

    # 9. Grafik 3: Yıl x ay ısı haritası.
    fig, axes = plt.subplots(
        1, 2,
        figsize=(13, 5),
        constrained_layout=True
    )

    for ax, flag in zip(axes, FLAGS):
        sub = monthly_total[
            monthly_total["flag"] == flag
        ]

        mat = sub.pivot(
            index="year",
            columns="month",
            values="fishing_hours"
        ).reindex(
            index=YEARS,
            columns=range(1, 13)
        )

        im = ax.imshow(
            mat.values,
            aspect="auto",
            interpolation="nearest"
        )

        ax.set_title(flag)
        ax.set_xticks(range(12), range(1, 13))
        ax.set_yticks(range(3), YEARS)
        ax.set_xlabel("Ay")
        ax.set_ylabel("Yıl")

        fig.colorbar(
            im,
            ax=ax,
            label="Fishing hours (saat)"
        )

    fig.suptitle(
        "Guangdong Nanpeng – aylık yoğunluk (yıl/ay)",
        fontsize=14,
        fontweight="bold"
    )

    fig.savefig(
        OUT / "guangdong_aylik_yil_ay_isiharitasi.png",
        dpi=220,
        bbox_inches="tight"
    )
    plt.close(fig)

    # 10. Sonuçları Terminal'e yazdır.
    print("\nAylık analiz tamamlandı.")
    print(f"İşlenen dosya: {files_found}")
    print(f"Detay satırı: {len(result):,}")
    print(f"Çıktı klasörü: {OUT}")

    print("\nYıllık toplamlar (üç hücre):")

    annual = (
        monthly_total.groupby(
            ["year", "flag"]
        )["fishing_hours"]
        .sum()
        .unstack()
    )

    print(annual.round(2).to_string())

    print("\nEn yüksek 5 ay (bayrak bazında):")

    for flag in FLAGS:
        top = (
            monthly_total[monthly_total["flag"] == flag]
            .nlargest(5, "fishing_hours")
        )

        print(f"\n{flag}")
        print(
            top[["date", "fishing_hours"]].to_string(index=False)
        )

    print("\nOluşturulan dosyalar:")
    for filename in [
        "guangdong_3_hucre_aylik_detay.csv",
        "guangdong_aylik_bayrak_toplam.csv",
        "guangdong_aylik_zaman_serisi.png",
        "guangdong_aylik_hucre_grafigi.png",
        "guangdong_aylik_yil_ay_isiharitasi.png"
    ]:
        print(f"- {OUT / filename}")


if __name__ == "__main__":
    main()
