"""Adım 4: 2022→2023 av saati sıçramasının veri kalitesi / kapsam kontrolü.

Girdi:  outputs/year_month_flag_gear.csv   (gfw_analiz.py üretir; 2,5 GB'lık CSV'yi tekrar okumaz)
Çıktı:  outputs/kalite_*.csv, outputs/kalite_ozet.png

Bu betik sıçramanın sebebini KANITLAMAZ; sadece ipuçlarını toplar:
- artış birkaç bayrakta mı yoğun, yoksa her yerde mi yayılmış?
- artış belirli bir ayda "basamak" yapıyor mu, yoksa yıl boyu mu?
- AIS saati ile av saati oranı (verimlilik) değişmiş mi?
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

OUT = Path(__file__).resolve().parent / "outputs"
SRC = OUT / "year_month_flag_gear.csv"
BASE_YEAR, COMPARE_YEAR = 2022, 2023
MIN_HOURS_FOR_GROWTH_TABLE = 500_000  # çok küçük filoların yüzdelik oynamasını eler


def contribution(df: pd.DataFrame, key: str, y0: int, y1: int) -> pd.DataFrame:
    p = df.pivot_table(index=key, columns="year", values="fishing_hours",
                       aggfunc="sum", fill_value=0)
    t = pd.DataFrame({f"fh_{y0}": p[y0], f"fh_{y1}": p[y1]})
    t["delta"] = t[f"fh_{y1}"] - t[f"fh_{y0}"]
    t["share_of_total_delta_pct"] = t["delta"] / t["delta"].sum() * 100
    t["pct_change"] = (t[f"fh_{y1}"] / t[f"fh_{y0}"].replace(0, np.nan) - 1) * 100
    return t.sort_values("delta", ascending=False)


def main() -> None:
    if not SRC.exists():
        raise SystemExit("outputs/year_month_flag_gear.csv yok. Önce gfw_analiz.py çalıştırın.")
    df = pd.read_csv(SRC)
    years = sorted(df["year"].unique())
    y0 = BASE_YEAR if BASE_YEAR in years else years[0]
    y1 = COMPARE_YEAR if COMPARE_YEAR in years else years[1]
    print(f"Karşılaştırma: {y0} → {y1}\n")

    # 1) Genel resim
    yearly = df.groupby("year")[["hours", "fishing_hours"]].sum()
    yearly["fishing_ratio_pct"] = yearly["fishing_hours"] / yearly["hours"] * 100
    yearly["fishing_growth_pct"] = yearly["fishing_hours"].pct_change() * 100
    yearly["ais_hours_growth_pct"] = yearly["hours"].pct_change() * 100
    print("1) Yıllık toplamlar ve av/AIS oranı")
    print(yearly.round(2).to_string(), "\n")

    # 2) Artış kimden geliyor? (bayrak ve av aracı)
    by_flag = contribution(df, "flag", y0, y1)
    by_gear = contribution(df, "geartype", y0, y1)
    by_flag.to_csv(OUT / "kalite_jump_by_flag.csv")
    by_gear.to_csv(OUT / "kalite_jump_by_gear.csv")

    total_delta = by_flag["delta"].sum()
    top5_share = by_flag["delta"].head(5).sum() / total_delta * 100
    active = by_flag[(by_flag[f"fh_{y0}"] > 0) | (by_flag[f"fh_{y1}"] > 0)]
    growing = int((active["delta"] > 0).sum())
    print(f"2) Toplam artış: {total_delta:,.0f} saat")
    print(f"   İlk 5 bayrak artışın %{top5_share:.0f}'ini açıklıyor.")
    print(f"   Aktif {len(active)} bayrağın {growing} tanesinde artış var "
          f"(%{growing / len(active) * 100:.0f}).")
    print("\n   Artışa en çok katkı yapan 10 bayrak:")
    print(by_flag.head(10).round(1).to_string())
    print("\n   Artışa en çok katkı yapan av araçları:")
    print(by_gear.head(6).round(1).to_string())

    leaders = by_flag[by_flag[f"fh_{y1}"] >= MIN_HOURS_FOR_GROWTH_TABLE].sort_values(
        "pct_change", ascending=False
    )
    print(f"\n   Hızlı büyüyenler ({y1} av saati >= {MIN_HOURS_FOR_GROWTH_TABLE:,}):")
    print(leaders.head(8)[[f"fh_{y0}", f"fh_{y1}", "pct_change"]].round(1).to_string())

    # 3) Basamak mı, yıl boyu mu? Ay ay karşılaştırma
    ym = df.groupby(["year", "month"])["fishing_hours"].sum().reset_index()
    ym["date"] = pd.to_datetime(dict(year=ym["year"], month=ym["month"], day=1))
    ym = ym.sort_values("date").reset_index(drop=True)
    ym["mom_pct"] = ym["fishing_hours"].pct_change() * 100
    monthly = ym.pivot(index="month", columns="year", values="fishing_hours")
    monthly["yoy_ratio"] = monthly[y1] / monthly[y0]
    monthly.to_csv(OUT / "kalite_monthly_yoy.csv")
    print(f"\n3) Aylık {y1}/{y0} oranı (hepsi benzerse artış yıl boyu yayılıyor):")
    print(monthly["yoy_ratio"].round(2).to_string())
    biggest = ym.loc[ym["mom_pct"].abs().nlargest(3).index, ["date", "fishing_hours", "mom_pct"]]
    print("\n   Aydan aya en büyük 3 değişim:")
    print(biggest.assign(fishing_hours=biggest["fishing_hours"].round(0),
                         mom_pct=biggest["mom_pct"].round(1)).to_string(index=False))

    print(
        "\nYorum için not: artış çok sayıda bayrakta ve her ayda benzerse kapsam/sınıflandırma "
        "değişikliği şüphesi artar; birkaç bayrakta yoğunsa gerçek filo değişimi daha olasıdır. "
        "Bu tablo kanıt değil ipucudur."
    )

    # Grafikler
    fig, axes = plt.subplots(3, 1, figsize=(11, 15))
    top = by_flag["delta"].head(10).iloc[::-1]
    axes[0].barh(top.index, top.values, color="#c2578f")
    axes[0].set(title=f"{y0}→{y1} av saati artışına en çok katkı yapan 10 bayrak", xlabel="Δ av saati")
    axes[0].grid(axis="x", alpha=0.25)

    axes[1].plot(ym["date"], ym["fishing_hours"], marker="o", color="#7a4fa3", linewidth=2)
    axes[1].set(title="Aylık av saati (tüm dönem)", ylabel="Av saati")
    axes[1].grid(alpha=0.25)

    axes[2].bar(monthly.index, monthly["yoy_ratio"], color="#e8a0bf")
    axes[2].axhline(yearly.loc[y1, "fishing_hours"] / yearly.loc[y0, "fishing_hours"],
                    color="k", linestyle="--", linewidth=1, label="yıllık ortalama oran")
    axes[2].set(title=f"Aylık {y1}/{y0} oranı", xlabel="Ay", ylabel="Oran")
    axes[2].set_xticks(range(1, 13))
    axes[2].legend()
    axes[2].grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(OUT / "kalite_ozet.png", dpi=160)
    plt.close(fig)
    print(f"\nKaydedildi: {OUT}")


if __name__ == "__main__":
    main()
