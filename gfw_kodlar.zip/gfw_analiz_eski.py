"""Global Fishing Watch aylık balıkçılık eforu: yıl/bayrak/araç kırılımlı başlangıç analizi.

Klasör düzeni (script ile aynı yerde, iç içe de olabilir):
    fleet-monthly-csvs-10-v3-2022/fleet-monthly-csvs-10-v3-2022-01-01.csv ...
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import pandas as pd

PROJECT_DIR = Path(__file__).resolve().parent
DATA_DIR = PROJECT_DIR
OUTPUT_DIR = PROJECT_DIR / "outputs"
CHUNK_SIZE = 1_000_000

COLUMNS = ["year", "month", "cell_ll_lat", "cell_ll_lon",
           "flag", "geartype", "hours", "fishing_hours"]
SUM_COLUMNS = ["hours", "fishing_hours"]
KEYS = ["year", "month", "flag", "geartype"]


def find_monthly_files() -> list[Path]:
    files = sorted(DATA_DIR.rglob("fleet-monthly-csvs-10-v3-20??-??-??.csv"))
    if not files:
        raise FileNotFoundError(
            "Aylık CSV bulunamadı. Açılmış 2022-2024 klasörlerini script'in "
            "yanına koyun."
        )
    return files


def aggregate_data(files: list[Path]) -> tuple[pd.DataFrame, pd.DataFrame]:
    """İki küçük tablo üretir:
    1) year, month, flag, geartype bazında saatler (tüm analizlerin temeli)
    2) year bazında 1 derecelik ızgara (harita için)
    """
    main_parts: list[pd.DataFrame] = []
    grid_parts: list[pd.DataFrame] = []

    for n, path in enumerate(files, start=1):
        print(f"[{n}/{len(files)}] Okunuyor: {path.name}")
        for chunk in pd.read_csv(path, usecols=COLUMNS, chunksize=CHUNK_SIZE):
            chunk["flag"] = chunk["flag"].fillna("Unknown")
            chunk["geartype"] = chunk["geartype"].fillna("Unknown")
            chunk["lat"] = chunk["cell_ll_lat"].floordiv(1).astype("int16")
            chunk["lon"] = chunk["cell_ll_lon"].floordiv(1).astype("int16")

            main_parts.append(chunk.groupby(KEYS, as_index=False)[SUM_COLUMNS].sum())
            grid_parts.append(
                chunk.groupby(["year", "lat", "lon"], as_index=False)["fishing_hours"].sum()
            )

    main = pd.concat(main_parts, ignore_index=True).groupby(KEYS, as_index=False)[SUM_COLUMNS].sum()
    grid = pd.concat(grid_parts, ignore_index=True).groupby(["year", "lat", "lon"], as_index=False)["fishing_hours"].sum()
    return main, grid


def save_outputs(main: pd.DataFrame, grid: pd.DataFrame) -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    main.to_csv(OUTPUT_DIR / "year_month_flag_gear.csv", index=False)
    grid.to_csv(OUTPUT_DIR / "grid_1deg_by_year.csv", index=False)

    yearly = main.groupby("year")[SUM_COLUMNS].sum()
    print("\nYıllık toplamlar:")
    print(yearly.round(0))

    # 1) Mevsimsellik: üç yıl üst üste
    seasonal = main.groupby(["year", "month"])["fishing_hours"].sum().unstack(0)
    fig, ax = plt.subplots(figsize=(11, 6))
    seasonal.plot(ax=ax, marker="o", linewidth=2)
    ax.set(title="Aylık görünür av saati (yıllara göre)", xlabel="Ay", ylabel="Av saati")
    ax.set_xticks(range(1, 13))
    ax.grid(True, alpha=0.25)
    fig.tight_layout()
    fig.savefig(OUTPUT_DIR / "seasonality_by_year.png", dpi=160)
    plt.close(fig)

    # 2) İlk 10 bayrak, yıllara göre
    flag_year = main.groupby(["flag", "year"])["fishing_hours"].sum().unstack(1).fillna(0)
    top_flags = flag_year.sum(axis=1).nlargest(10).index
    fig, ax = plt.subplots(figsize=(11, 6))
    flag_year.loc[top_flags].sort_values(flag_year.columns[-1]).plot.barh(ax=ax)
    ax.set(title="İlk 10 bayrak: yıllık av saati", xlabel="Av saati", ylabel="Bayrak")
    ax.grid(axis="x", alpha=0.25)
    fig.tight_layout()
    fig.savefig(OUTPUT_DIR / "top_flags_by_year.png", dpi=160)
    plt.close(fig)

    # 3) Av aracı türleri
    gears = main.groupby("geartype")["fishing_hours"].sum().nlargest(10).sort_values()
    fig, ax = plt.subplots(figsize=(10, 6))
    gears.plot.barh(ax=ax, color="#087e8b")
    ax.set(title="Av aracı türüne göre av saati", xlabel="Av saati", ylabel="Av aracı")
    ax.grid(axis="x", alpha=0.25)
    fig.tight_layout()
    fig.savefig(OUTPUT_DIR / "top_gear_types.png", dpi=160)
    plt.close(fig)

    print(f"\nToplam av saati: {main['fishing_hours'].sum():,.0f}")
    print(f"Sonuçlar: {OUTPUT_DIR}")


def main_() -> None:
    files = find_monthly_files()
    main, grid = aggregate_data(files)
    save_outputs(main, grid)


if __name__ == "__main__":
    main_()
