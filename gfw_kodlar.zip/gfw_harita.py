"""Adım 5: Dünya balıkçılık eforu haritaları (yıl yan yana + değişim haritası).

Girdi:  outputs/grid_1deg_by_year.csv   (gfw_analiz.py üretir)
Çıktı:  outputs/harita_yillar.png, outputs/harita_degisim.png, outputs/harita_top_hucreler.csv

Ek kütüphane gerekmez (matplotlib yeterli). Kıyı çizgisi yok; veri olmayan yerler
(kara ve hiç gemi görülmeyen deniz) arka plan renginde kalır ve kıtaları belli eder.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LogNorm, SymLogNorm

OUT = Path(__file__).resolve().parent / "outputs"
SRC = OUT / "grid_1deg_by_year.csv"

# Palet ayarları (istersen değiştir)
CMAP_DENSITY = "RdPu"      # yoğunluk haritası
CMAP_CHANGE = "PiYG"       # değişim haritası (pembe = azalış, yeşil = artış)
BACKGROUND = "#f3eef8"     # veri olmayan yerler
LAT_RANGE = (-60, 85)


def to_grid(frame: pd.DataFrame) -> np.ndarray:
    """1°'lik 180x360 ızgara (satır: enlem -90..89, sütun: boylam -180..179)."""
    grid = np.zeros((180, 360))
    rows = (frame["lat"].to_numpy(dtype=int) + 90)
    cols = (frame["lon"].to_numpy(dtype=int) + 180)
    ok = (rows >= 0) & (rows < 180) & (cols >= 0) & (cols < 360)
    np.add.at(grid, (rows[ok], cols[ok]), frame["fishing_hours"].to_numpy()[ok])
    return grid


def draw(ax, data, norm, cmap, title):
    ax.set_facecolor(BACKGROUND)
    masked = np.ma.masked_where(data == 0, data)
    im = ax.imshow(masked, origin="lower", extent=[-180, 180, -90, 90],
                   norm=norm, cmap=cmap, interpolation="nearest", aspect="auto")
    ax.set_ylim(*LAT_RANGE)
    ax.set_title(title, fontsize=13)
    ax.set_xticks(range(-180, 181, 60))
    ax.set_xlabel("Boylam")
    ax.set_ylabel("Enlem")
    return im


def main() -> None:
    if not SRC.exists():
        raise SystemExit("outputs/grid_1deg_by_year.csv yok. Önce gfw_analiz.py çalıştırın.")
    g = pd.read_csv(SRC)
    years = sorted(g["year"].unique())
    grids = {y: to_grid(g[g["year"] == y]) for y in years}

    # 1) Yıl yan yana yoğunluk haritaları (ortak log ölçek)
    vmax = max(arr.max() for arr in grids.values())
    norm = LogNorm(vmin=10, vmax=vmax)
    fig, axes = plt.subplots(len(years), 1, figsize=(13, 5.2 * len(years)), squeeze=False)
    for ax, y in zip(axes[:, 0], years):
        im = draw(ax, grids[y], norm, CMAP_DENSITY, f"{y}: görünür balıkçılık eforu")
    fig.colorbar(im, ax=axes[:, 0].tolist(), shrink=0.8, pad=0.02,
                 label="Av saati (1°×1° hücre, log ölçek)")
    fig.savefig(OUT / "harita_yillar.png", dpi=150, bbox_inches="tight")
    plt.close(fig)

    # 2) Değişim haritası: son yıl - ilk yıl
    y0, y1 = years[0], years[-1]
    diff = grids[y1] - grids[y0]
    diff[(grids[y0] == 0) & (grids[y1] == 0)] = 0
    limit = np.percentile(np.abs(diff[diff != 0]), 99) if np.any(diff != 0) else 1
    fig, ax = plt.subplots(figsize=(13, 5.8))
    im = draw(ax, diff, SymLogNorm(linthresh=50, vmin=-limit, vmax=limit),
              CMAP_CHANGE, f"Değişim: {y1} − {y0} (yeşil artış, pembe azalış)")
    fig.colorbar(im, ax=ax, shrink=0.85, pad=0.02, label="Δ av saati (simetrik log ölçek)")
    fig.savefig(OUT / "harita_degisim.png", dpi=150, bbox_inches="tight")
    plt.close(fig)

    # 3) Her yılın en yoğun 20 hücresi
    tops = (g.sort_values("fishing_hours", ascending=False)
             .groupby("year").head(20).sort_values(["year", "fishing_hours"], ascending=[True, False]))
    tops.to_csv(OUT / "harita_top_hucreler.csv", index=False)
    print("En yoğun hücreler (yıl başına ilk 5):")
    print(tops.groupby("year").head(5).round(0).to_string(index=False))
    print(f"\nKaydedildi: {OUT}")


if __name__ == "__main__":
    main()
